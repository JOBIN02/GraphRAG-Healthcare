from graphrag_core import build_index_from_txts

build_index_from_txts()